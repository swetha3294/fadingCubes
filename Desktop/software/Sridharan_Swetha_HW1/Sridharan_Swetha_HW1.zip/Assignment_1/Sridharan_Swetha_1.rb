def palindrome?(string)
  string= string.downcase.gsub(/[-!' ,;]/,"") #Converts to lower case and removes special characters
  puts string==string.reverse #Checks if it is a palindrome
end

palindrome?("A man, a plan, a canal -- Panama")  #=> true
palindrome?("Madam, I'm Adam!")  # => true
palindrome?("Abracadabra") # => false